from kivymd.uix.behaviors import StencilBehavior
from kivymd.uix.screen import MDScreen
from kivymd.app import MDApp
from os.path import dirname, abspath
import sys
sys.path.append(dirname(dirname(dirname(abspath(__file__)))))
from utils.validacoes import Validacao


class TelaCadastroUsuario(MDScreen, StencilBehavior):
    def __init__(self, **kw):
        super().__init__(**kw)
        print("Tela Cadastro Usuario inicializada com sucesso.")
        
    def on_pre_enter(self, *args):
        self.limparTudo()

    def on_enter(self, *args):
        pass

    def irParaTela(self, tela: str, direcao: str) -> None:
        print(f"Carregando: {tela}, direção: {direcao}")
        self.app = MDApp.get_running_app()
        self.app.root.transition.direction = direcao
        self.app.root.current = tela

    def irParaTelaRegistrarUsuario(self, *args):
        print("Realizando Cadastro de Novo usuário!")
        self.irParaTela(tela="tela_login", direcao="right")

    def limparTudo(self) -> None:
        self.ids.nome_field.text = ""
        self.ids.nome_field_txt_erro.text = ""
        self.ids.username_field.text = ""
        self.ids.username_field_txt_erro.text = ""
        self.ids.setor_field.text = ""
        self.ids.setor_field_txt_erro.text = ""
        self.ids.email_field.text = ""
        self.ids.email_field_txt_erro.text = ""
        self.ids.senha_field.text = ""
        self.ids.senha_field_txt_erro.text = ""
        self.ids.confirmar_senha_field.text = ""
        self.ids.confirmar_senha_field_txt_erro.text = ""

    def validarDados(self, *args):
        self.validarEmail()
        self.validarUsername()


    def validarEmail(self, *args):
        email_valid = Validacao().validarEmail(self.ids.email_field.text)
        self.ids.email_field_txt_erro.text = email_valid[2]
        
        if email_valid[0]:
            self.ids.email_field_txt_erro.text_color = [0.00,0.65,0.00]
        else:
            self.ids.email_field_txt_erro.text_color = [0.99,0.00,0.00]

    def validarUsername(self, *args):
        username_valid = Validacao().validaUsername(self.ids.username_field.text)
        self.ids.username_field_txt_erro.text = username_valid[2]

        if username_valid[0]:
            self.ids.username_field_txt_erro.text_color = [0.00,0.65,0.00]
        else:
            self.ids.username_field_txt_erro.text_color = [0.99,0.00,0.00]

    def validarNome(self, *args):
        pass

    def confirmarSenhas(self, *args):
        pass

    


if __name__ == "__main__":
    ...