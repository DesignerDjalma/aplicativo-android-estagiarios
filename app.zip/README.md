# aplicativo-android-estagiarios
Um upgrade da aplicação de Cadastro.
